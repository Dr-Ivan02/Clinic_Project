CREATE DATABASE ClinicaMultiespecialidadDB
GO
USE ClinicaMultiespecialidadDB

SET XACT_ABORT ON;
GO

/*    1. Catálogos y seguridad */

CREATE TABLE dbo.Rol (
    RolID           TINYINT IDENTITY(1,1) NOT NULL,
    Nombre          VARCHAR(30) NOT NULL,
    Descripcion     VARCHAR(200) NULL,
    CONSTRAINT PK_Rol PRIMARY KEY (RolID),
    CONSTRAINT UQ_Rol_Nombre UNIQUE (Nombre)
);
GO

CREATE TABLE dbo.Paciente (
    PacienteID      INT IDENTITY(1,1) NOT NULL,
    Cedula          VARCHAR(11) NOT NULL,
    Nombres         NVARCHAR(80) NOT NULL,
    Apellidos       NVARCHAR(80) NOT NULL,
    FechaNacimiento DATE NULL,
    Telefono        VARCHAR(20) NULL,
    Correo          VARCHAR(254) NULL,
    Direccion       NVARCHAR(250) NULL,
    FechaRegistro   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Paciente_FechaRegistro DEFAULT (SYSDATETIME()),
    Activo          BIT NOT NULL
        CONSTRAINT DF_Paciente_Activo DEFAULT (1),
    CONSTRAINT PK_Paciente PRIMARY KEY (PacienteID),
    CONSTRAINT UQ_Paciente_Cedula UNIQUE (Cedula),
    CONSTRAINT CK_Paciente_Cedula_NoVacia CHECK (LEN(LTRIM(RTRIM(Cedula))) > 0),
    CONSTRAINT CK_Paciente_FechaNacimiento CHECK
        (FechaNacimiento IS NULL OR FechaNacimiento <= CONVERT(date, SYSDATETIME()))
);
GO

CREATE TABLE dbo.Medico (
    MedicoID        INT IDENTITY(1,1) NOT NULL,
    Nombres         NVARCHAR(80) NOT NULL,
    Apellidos       NVARCHAR(80) NOT NULL,
    NumeroExequatur VARCHAR(30) NOT NULL,
    Telefono        VARCHAR(20) NULL,
    Correo          VARCHAR(254) NULL,
    Activo          BIT NOT NULL
        CONSTRAINT DF_Medico_Activo DEFAULT (1),
    CONSTRAINT PK_Medico PRIMARY KEY (MedicoID),
    CONSTRAINT UQ_Medico_NumeroExequatur UNIQUE (NumeroExequatur)
);
GO

CREATE TABLE dbo.Especialidad (
    EspecialidadID  INT IDENTITY(1,1) NOT NULL,
    Nombre          NVARCHAR(100) NOT NULL,
    Descripcion     NVARCHAR(300) NULL,
    Activa          BIT NOT NULL
        CONSTRAINT DF_Especialidad_Activa DEFAULT (1),
    CONSTRAINT PK_Especialidad PRIMARY KEY (EspecialidadID),
    CONSTRAINT UQ_Especialidad_Nombre UNIQUE (Nombre)
);
GO

CREATE TABLE dbo.MedicoEspecialidad (
    MedicoID        INT NOT NULL,
    EspecialidadID  INT NOT NULL,
    FechaAsignacion DATE NOT NULL
        CONSTRAINT DF_MedicoEspecialidad_Fecha DEFAULT (CONVERT(date, SYSDATETIME())),
    CONSTRAINT PK_MedicoEspecialidad PRIMARY KEY (MedicoID, EspecialidadID),
    CONSTRAINT FK_MedicoEspecialidad_Medico FOREIGN KEY (MedicoID)
        REFERENCES dbo.Medico (MedicoID),
    CONSTRAINT FK_MedicoEspecialidad_Especialidad FOREIGN KEY (EspecialidadID)
        REFERENCES dbo.Especialidad (EspecialidadID)
);
GO

CREATE TABLE dbo.Usuario (
    UsuarioID       INT IDENTITY(1,1) NOT NULL,
    RolID           TINYINT NOT NULL,
    MedicoID        INT NULL,
    NombreUsuario   VARCHAR(80) NOT NULL,
    HashContrasena  VARCHAR(255) NOT NULL,
    Correo          VARCHAR(254) NULL,
    Activo          BIT NOT NULL
        CONSTRAINT DF_Usuario_Activo DEFAULT (1),
    FechaCreacion   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Usuario_FechaCreacion DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Usuario PRIMARY KEY (UsuarioID),
    CONSTRAINT UQ_Usuario_NombreUsuario UNIQUE (NombreUsuario),
    CONSTRAINT FK_Usuario_Rol FOREIGN KEY (RolID) REFERENCES dbo.Rol (RolID),
    CONSTRAINT FK_Usuario_Medico FOREIGN KEY (MedicoID) REFERENCES dbo.Medico (MedicoID)
);
GO

/* =========================
   2. Expediente e historial
   ========================= */

CREATE TABLE dbo.Expediente (
    ExpedienteID    INT IDENTITY(1,1) NOT NULL,
    PacienteID      INT NOT NULL,
    FechaApertura   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Expediente_FechaApertura DEFAULT (SYSDATETIME()),
    ObservacionesGenerales NVARCHAR(1000) NULL,
    CONSTRAINT PK_Expediente PRIMARY KEY (ExpedienteID),
    CONSTRAINT UQ_Expediente_Paciente UNIQUE (PacienteID),
    CONSTRAINT FK_Expediente_Paciente FOREIGN KEY (PacienteID)
        REFERENCES dbo.Paciente (PacienteID)
);
GO

CREATE TABLE dbo.Antecedente (
    AntecedenteID   INT IDENTITY(1,1) NOT NULL,
    ExpedienteID    INT NOT NULL,
    Tipo            VARCHAR(20) NOT NULL, -- Personal, Familiar, Alergia, Quirurgico, Otro
    Descripcion     NVARCHAR(1000) NOT NULL,
    FechaRegistro   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Antecedente_Fecha DEFAULT (SYSDATETIME()),
    RegistradoPorUsuarioID INT NULL,
    CONSTRAINT PK_Antecedente PRIMARY KEY (AntecedenteID),
    CONSTRAINT CK_Antecedente_Tipo CHECK
        (Tipo IN ('Personal','Familiar','Alergia','Quirurgico','Otro')),
    CONSTRAINT FK_Antecedente_Expediente FOREIGN KEY (ExpedienteID)
        REFERENCES dbo.Expediente (ExpedienteID),
    CONSTRAINT FK_Antecedente_Usuario FOREIGN KEY (RegistradoPorUsuarioID)
        REFERENCES dbo.Usuario (UsuarioID)
);
GO

/* =========================
   3. Agenda y consultas
   ========================= */

CREATE TABLE dbo.Cita (
    CitaID          BIGINT IDENTITY(1,1) NOT NULL,
    PacienteID      INT NOT NULL,
    MedicoID        INT NOT NULL,
    EspecialidadID  INT NOT NULL,
    FechaHoraInicio DATETIME2(0) NOT NULL,
    FechaHoraFin    DATETIME2(0) NOT NULL,
    Estado          VARCHAR(20) NOT NULL
        CONSTRAINT DF_Cita_Estado DEFAULT ('Programada'),
    Motivo          NVARCHAR(500) NULL,
    CreadaPorUsuarioID INT NULL,
    FechaCreacion   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Cita_FechaCreacion DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Cita PRIMARY KEY (CitaID),
    CONSTRAINT CK_Cita_RangoHorario CHECK (FechaHoraFin > FechaHoraInicio),
    CONSTRAINT CK_Cita_Estado CHECK
        (Estado IN ('Programada','Confirmada','En curso','Completada','Cancelada','No asistio')),
    CONSTRAINT FK_Cita_Paciente FOREIGN KEY (PacienteID)
        REFERENCES dbo.Paciente (PacienteID),
    CONSTRAINT FK_Cita_MedicoEspecialidad FOREIGN KEY (MedicoID, EspecialidadID)
        REFERENCES dbo.MedicoEspecialidad (MedicoID, EspecialidadID),
    CONSTRAINT FK_Cita_Creador FOREIGN KEY (CreadaPorUsuarioID)
        REFERENCES dbo.Usuario (UsuarioID)
);
GO

CREATE TABLE dbo.ConsultaMedica (
    ConsultaID      BIGINT IDENTITY(1,1) NOT NULL,
    ExpedienteID    INT NOT NULL,
    CitaID          BIGINT NULL,
    MedicoID        INT NOT NULL,
    FechaHora       DATETIME2(0) NOT NULL
        CONSTRAINT DF_Consulta_FechaHora DEFAULT (SYSDATETIME()),
    MotivoConsulta  NVARCHAR(500) NULL,
    Sintomas        NVARCHAR(MAX) NULL,
    NotasClinicas   NVARCHAR(MAX) NOT NULL,
    PlanSeguimiento NVARCHAR(1000) NULL,
    RegistradaPorUsuarioID INT NULL,
    CONSTRAINT PK_ConsultaMedica PRIMARY KEY (ConsultaID),
    CONSTRAINT FK_ConsultaMedica_Expediente FOREIGN KEY (ExpedienteID)
        REFERENCES dbo.Expediente (ExpedienteID),
    CONSTRAINT FK_ConsultaMedica_Cita FOREIGN KEY (CitaID)
        REFERENCES dbo.Cita (CitaID),
    CONSTRAINT FK_ConsultaMedica_Medico FOREIGN KEY (MedicoID)
        REFERENCES dbo.Medico (MedicoID),
    CONSTRAINT FK_ConsultaMedica_Usuario FOREIGN KEY (RegistradaPorUsuarioID)
        REFERENCES dbo.Usuario (UsuarioID)
);
GO

CREATE TABLE dbo.Diagnostico (
    DiagnosticoID   BIGINT IDENTITY(1,1) NOT NULL,
    ConsultaID      BIGINT NOT NULL,
    Codigo          VARCHAR(30) NULL,
    Descripcion     NVARCHAR(500) NOT NULL,
    Tipo            VARCHAR(20) NOT NULL
        CONSTRAINT DF_Diagnostico_Tipo DEFAULT ('Principal'),
    FechaRegistro   DATETIME2(0) NOT NULL
        CONSTRAINT DF_Diagnostico_Fecha DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Diagnostico PRIMARY KEY (DiagnosticoID),
    CONSTRAINT CK_Diagnostico_Tipo CHECK (Tipo IN ('Principal','Secundario','Presuntivo')),
    CONSTRAINT FK_Diagnostico_Consulta FOREIGN KEY (ConsultaID)
        REFERENCES dbo.ConsultaMedica (ConsultaID)
);
GO

CREATE TABLE dbo.Tratamiento (
    TratamientoID   BIGINT IDENTITY(1,1) NOT NULL,
    ConsultaID      BIGINT NOT NULL,
    Descripcion     NVARCHAR(500) NOT NULL,
    Instrucciones   NVARCHAR(1000) NULL,
    FechaInicio     DATE NULL,
    FechaFin        DATE NULL,
    CONSTRAINT PK_Tratamiento PRIMARY KEY (TratamientoID),
    CONSTRAINT CK_Tratamiento_Fechas CHECK
        (FechaInicio IS NULL OR FechaFin IS NULL OR FechaFin >= FechaInicio),
    CONSTRAINT FK_Tratamiento_Consulta FOREIGN KEY (ConsultaID)
        REFERENCES dbo.ConsultaMedica (ConsultaID)
);
GO

/* =========================
   4. Facturación y pagos
   ========================= */

CREATE TABLE dbo.Factura (
    FacturaID       BIGINT IDENTITY(1,1) NOT NULL,
    ConsultaID      BIGINT NOT NULL,
    NumeroFactura   VARCHAR(40) NOT NULL,
    FechaEmision    DATETIME2(0) NOT NULL
        CONSTRAINT DF_Factura_Fecha DEFAULT (SYSDATETIME()),
    Subtotal        DECIMAL(12,2) NOT NULL,
    Impuestos       DECIMAL(12,2) NOT NULL
        CONSTRAINT DF_Factura_Impuestos DEFAULT (0),
    Total           AS (Subtotal + Impuestos) PERSISTED,
    Estado          VARCHAR(20) NOT NULL
        CONSTRAINT DF_Factura_Estado DEFAULT ('Pendiente'),
    CreadaPorUsuarioID INT NULL,
    CONSTRAINT PK_Factura PRIMARY KEY (FacturaID),
    CONSTRAINT UQ_Factura_Numero UNIQUE (NumeroFactura),
    CONSTRAINT UQ_Factura_Consulta UNIQUE (ConsultaID),
    CONSTRAINT CK_Factura_Montos CHECK (Subtotal >= 0 AND Impuestos >= 0),
    CONSTRAINT CK_Factura_Estado CHECK (Estado IN ('Pendiente','Pagada','Anulada')),
    CONSTRAINT FK_Factura_Consulta FOREIGN KEY (ConsultaID)
        REFERENCES dbo.ConsultaMedica (ConsultaID),
    CONSTRAINT FK_Factura_Usuario FOREIGN KEY (CreadaPorUsuarioID)
        REFERENCES dbo.Usuario (UsuarioID)
);
GO

CREATE TABLE dbo.Pago (
    PagoID          BIGINT IDENTITY(1,1) NOT NULL,
    FacturaID       BIGINT NOT NULL,
    FechaPago       DATETIME2(0) NOT NULL
        CONSTRAINT DF_Pago_Fecha DEFAULT (SYSDATETIME()),
    Monto           DECIMAL(12,2) NOT NULL,
    MetodoPago      VARCHAR(20) NOT NULL,
    Referencia      VARCHAR(100) NULL,
    RegistradoPorUsuarioID INT NULL,
    CONSTRAINT PK_Pago PRIMARY KEY (PagoID),
    CONSTRAINT CK_Pago_Monto CHECK (Monto > 0),
    CONSTRAINT CK_Pago_Metodo CHECK
        (MetodoPago IN ('Efectivo','Tarjeta','Transferencia','Seguro','Otro')),
    CONSTRAINT FK_Pago_Factura FOREIGN KEY (FacturaID)
        REFERENCES dbo.Factura (FacturaID),
    CONSTRAINT FK_Pago_Usuario FOREIGN KEY (RegistradoPorUsuarioID)
        REFERENCES dbo.Usuario (UsuarioID)
);
GO

/* =========================
   5. Índices para consultas frecuentes
   ========================= */

CREATE INDEX IX_Paciente_Apellidos_Nombres
    ON dbo.Paciente (Apellidos, Nombres);

CREATE INDEX IX_Cita_Medico_Horario
    ON dbo.Cita (MedicoID, FechaHoraInicio, FechaHoraFin)
    INCLUDE (Estado, PacienteID, EspecialidadID);

CREATE INDEX IX_Cita_Paciente_Fecha
    ON dbo.Cita (PacienteID, FechaHoraInicio DESC);

CREATE INDEX IX_Consulta_Expediente_Fecha
    ON dbo.ConsultaMedica (ExpedienteID, FechaHora DESC);

/* Un paciente puede tener consultas sin cita; solo las citas no nulas deben ser únicas. */
CREATE UNIQUE INDEX UX_ConsultaMedica_Cita
    ON dbo.ConsultaMedica (CitaID)
    WHERE CitaID IS NOT NULL;

CREATE INDEX IX_Diagnostico_Consulta
    ON dbo.Diagnostico (ConsultaID);

CREATE INDEX IX_Tratamiento_Consulta
    ON dbo.Tratamiento (ConsultaID);

CREATE INDEX IX_Antecedente_Expediente
    ON dbo.Antecedente (ExpedienteID);

CREATE INDEX IX_Pago_Factura_Fecha
    ON dbo.Pago (FacturaID, FechaPago DESC);
GO


INSERT INTO dbo.Rol (Nombre, Descripcion)
VALUES
    ('Administrador', 'Administra usuarios y configuración del sistema'),
    ('Secretaria', 'Gestiona pacientes, agenda y cobros según permisos asignados'),
    ('Medico', 'Accede al historial clínico y registra consultas');
GO